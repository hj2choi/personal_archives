Public Class frmRipple
    Inherits frmEffect

End Class
