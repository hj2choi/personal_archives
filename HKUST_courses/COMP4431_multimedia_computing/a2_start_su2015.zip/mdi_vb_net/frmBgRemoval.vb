Public Class frmBgRemoval
    Inherits frmEffect

End Class
