Module modGraph

    Public Structure PointData
        Dim x As Integer
        Dim y As Integer
        Dim operation As Integer
        Dim settings As Object
        Dim keyframe As Bitmap
    End Structure

End Module