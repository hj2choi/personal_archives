Public Class MotionBlurSettings
    Public blurCount As Integer = 5
End Class
