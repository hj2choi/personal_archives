Public Class MeltSettings
    Public useSine As Boolean = False
    Public amplitude As Integer = 5
    Public cycle As Integer = 5
    Public useRandom As Boolean = False
    Public offset As Integer = 5
    Public period As Integer = 5
End Class
