Public Class TransitionSettings
    Public type As Integer = 0
    Public duration As Double = 0.5
End Class

