Public Class FadeOutSettings
    Public endRate As Double = 0
End Class