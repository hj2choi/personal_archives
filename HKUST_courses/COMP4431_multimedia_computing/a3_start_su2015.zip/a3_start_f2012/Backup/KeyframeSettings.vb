Public Class KeyframeSettings
    Public threshold As Double = 0.3
    Public similarity As Double = 0.7
End Class
