﻿Public Class TimeShiftSettings
    Public cutOffPos As Double = 0.5
End Class
