Public Class FadeInSettings
    Public startRate As Double = 0
End Class
