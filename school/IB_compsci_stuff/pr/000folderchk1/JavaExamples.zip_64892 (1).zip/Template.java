public class Template extends IBIO		// Replace "Template" with
{										// your specific class name
	public static void main(String[] args)
	{
		
	}
}


/* OUTPUT OF YOUR PROGRAM (copy & paste from Terminal)

*/